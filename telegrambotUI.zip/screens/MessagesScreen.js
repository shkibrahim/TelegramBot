import React, { useEffect, useState } from 'react';
import { StyleSheet, View, Text, ScrollView } from 'react-native';
import { useRoute } from '@react-navigation/native';

export default function MessagesScreen() {
  const [messages, setMessages] = useState([]);
  const route = useRoute();
  const { channelName } = route.params;

  useEffect(() => {
    // Fetch messages from API using channelName
    // For now, we'll use static data
    setMessages([
      {
        date: '2024-07-13T17:06:30+00:00',
        message:
          '👑 These guys are actively trading with the help of the NEW - OTC AI Navigator Pro.',
        id: 15461,
      },
      {
        date: '2024-07-13T15:12:40+00:00',
        message:
          "Hello, traders! 👋 I love weekends because there's plenty of free time, calm trading.",
        id: 15459,
      },
      {
        date: '2024-07-13T13:15:05+00:00',
        message:
          '📹 HIGH PROFIT TRADING STRATEGY | HIGHEST SIGNAL ACCURACY | DAILY INCOME',
        id: 15458,
      },
    ]);
  }, []);

  const renderMessages = () => {
    if (messages.length === 0) {
      return <Text style={styles.cardText}>No messages fetched</Text>;
    }
    return messages.map((message) => (
      <View key={message.id} style={styles.card}>
        <Text style={styles.dateText}>Date: {new Date(message.date).toLocaleString()}</Text>
        <Text style={styles.messageText}>{message.message}</Text>
      </View>
    ));
  };

  return (
    <View style={styles.container}>
      <ScrollView style={styles.scrollView}>{renderMessages()}</ScrollView>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#fff',
    padding: 20,
  },
  card: {
    backgroundColor: '#f0f0f0',
    borderRadius: 10,
    padding: 15,
    marginVertical: 5,
    shadowColor: '#000',
    shadowOffset: {
      width: 0,
      height: 2,
    },
    shadowOpacity: 0.25,
    shadowRadius: 3.84,
    elevation: 5,
  },
  dateText: {
    fontSize: 12,
    color: 'gray',
    marginBottom: 5,
  },
  messageText: {
    fontSize: 16,
  },
  scrollView: {
    width: '100%',
    marginTop: 20,
    maxHeight: '80%',
  },
});
